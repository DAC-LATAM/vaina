#!/usr/bin/env bash

source ../_compiled_contracts/dacdirectory/compile_all.sh