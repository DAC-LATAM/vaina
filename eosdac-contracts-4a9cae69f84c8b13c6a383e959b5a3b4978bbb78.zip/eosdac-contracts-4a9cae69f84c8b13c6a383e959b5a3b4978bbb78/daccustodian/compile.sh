#!/usr/bin/env bash

source ../_compiled_contracts/daccustodian/compile_all.sh