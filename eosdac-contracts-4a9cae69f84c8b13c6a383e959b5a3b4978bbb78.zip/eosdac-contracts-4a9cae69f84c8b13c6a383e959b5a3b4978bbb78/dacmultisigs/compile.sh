#!/usr/bin/env bash

source ../_compiled_contracts/dacmultisigs/compile.sh