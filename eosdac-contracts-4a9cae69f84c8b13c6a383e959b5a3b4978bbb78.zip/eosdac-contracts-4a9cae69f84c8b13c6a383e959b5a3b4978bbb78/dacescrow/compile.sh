#!/usr/bin/env bash

source ../_compiled_contracts/dacescrow/compile_all.sh