#!/usr/bin/env bash

source ../_compiled_contracts/eosdactokens/compile_all.sh