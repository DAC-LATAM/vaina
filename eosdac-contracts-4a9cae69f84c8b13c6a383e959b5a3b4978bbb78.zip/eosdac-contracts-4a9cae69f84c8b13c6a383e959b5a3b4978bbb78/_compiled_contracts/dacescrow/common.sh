# set -x

CONTRACT='dacescrow'
