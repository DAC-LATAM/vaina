# set -x

CONTRACT='dacdirectory'
