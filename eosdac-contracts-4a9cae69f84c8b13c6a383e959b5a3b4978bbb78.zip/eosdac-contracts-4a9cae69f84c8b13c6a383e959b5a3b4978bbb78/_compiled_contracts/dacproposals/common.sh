# set -x

CONTRACT='dacproposals'
