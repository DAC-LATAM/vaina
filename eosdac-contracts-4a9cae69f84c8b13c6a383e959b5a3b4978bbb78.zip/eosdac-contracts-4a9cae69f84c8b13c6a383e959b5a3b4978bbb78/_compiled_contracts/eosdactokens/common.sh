# set -x

CONTRACT='eosdactokens'
