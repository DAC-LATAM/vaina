#!/usr/bin/env bash

eosio-cpp -o dacdirtester/dacdirtester.wasm dacdirtester.cpp -I.
