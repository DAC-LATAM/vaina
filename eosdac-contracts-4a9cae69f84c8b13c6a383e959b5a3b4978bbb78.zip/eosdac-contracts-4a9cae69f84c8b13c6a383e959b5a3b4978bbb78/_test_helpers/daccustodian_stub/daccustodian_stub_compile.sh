#!/usr/bin/env bash

eosio-cpp -o ./daccustodian/daccustodian.wasm ./daccustodian/daccustodian.cpp -I.

