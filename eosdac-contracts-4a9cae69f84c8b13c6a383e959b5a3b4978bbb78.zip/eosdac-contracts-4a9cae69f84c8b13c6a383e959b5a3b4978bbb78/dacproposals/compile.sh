#!/usr/bin/env bash

source ../_compiled_contracts/dacproposals/compile_all.sh